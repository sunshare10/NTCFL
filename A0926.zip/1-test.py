# %matplotlib inline
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
# from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from get_data import get_data2
from sklearn.metrics import confusion_matrix,classification_report
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
# from imblearn.over_sampling import RandomOverSampler
# X, y = make_classification(n_samples=5000, n_features=2, n_informative=2,
#                            n_redundant=0, n_repeated=0, n_classes=3,
#                            n_clusters_per_class=1,
#                            weights=[0.01, 0.05, 0.94],
#                            class_sep=0.8, random_state=0)
# args = args_parser()
NUM_HEADERS=24
PCK_LEN=1500
# device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
t=1

Xtrain,Ytrain,Xtest,Ytest=get_data2(num_headers = NUM_HEADERS,pck_len=PCK_LEN,t=t)
# ros = RandomOverSampler(random_state=0)
# Xtrain, Ytrain = ros.fit_resample(Xtrain, Ytrain)
# Xtest, Ytest = ros.fit_resample(Xtest, Ytest)
# from collections import Counter
# print(sorted(Counter(Ytrain).items()))



# clf = DecisionTreeClassifier(random_state=0)
rfc = RandomForestClassifier(random_state=0)
# clf = clf.fit(Xtrain,Ytrain)
rfc = rfc.fit(Xtrain,Ytrain)
# score_c = clf.score(Xtest,Ytest)
score_r = rfc.score(Xtest,Ytest)
print("Random Forest:{}".format(score_r)
     )
# print("Decision Tree:{}".format(score_c)
     # )

    
guess = rfc.predict(Xtest)
fact = Ytest
print(classification_report(fact,guess,digits=5))
# 试图绘制ROC曲线失败
# num_classes=7
# labels=['drtv','hbo','http','https','netflix','twitch','youtube']
# plot_ROC(fact, guess, num_classes, labels, micro=False, macro=False)
classes = list(set(fact))
classes.sort()
confusion = confusion_matrix(guess, fact)
plt.imshow(confusion, cmap=plt.cm.Blues)
indices = range(len(confusion))
plt.xticks(indices, classes)
plt.yticks(indices, classes)
plt.colorbar()
plt.xlabel('guess')
plt.ylabel('fact')
for first_index in range(len(confusion)):
     for second_index in range(len(confusion[first_index])):
          plt.text(first_index, second_index, confusion[first_index][second_index])
plt.show()